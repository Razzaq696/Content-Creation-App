package com.abdultool.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.api.ApiClient;
import com.abdultool.utils.FileDownloader;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONObject;

import java.io.*;

public class FaceFilterActivity extends AppCompatActivity {

    // Video source
    Button      btnUseDownloaded, btnPickVideo;
    TextView    tvVideoInfo;

    // Reference image
    LinearLayout layoutRefImage;
    Button      btnPickRefImage;
    TextView    tvRefImageInfo;

    // Detection mode
    RadioButton rbAnyFace, rbSpecificFace;

    // Controls
    Button      btnStartFilter, btnSaveMatched;
    TextView    tvStatus, tvResult, tvJobInfo;
    ProgressBar progressBar;

    SharedPreferences prefs;
    Handler  handler = new Handler();
    Runnable pollRunnable;
    boolean  isPollRunning = false;
    String   currentJobId = null;

    private static final int REQ_PICK_VIDEO = 201;
    private static final int REQ_PICK_IMAGE = 202;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_filter);

        prefs = getSharedPreferences("AbdulTool", MODE_PRIVATE);

        // Video source views
        btnUseDownloaded = findViewById(R.id.btnFFUseDownloaded);
        btnPickVideo     = findViewById(R.id.btnFFPickVideo);
        tvVideoInfo      = findViewById(R.id.tvFFVideoInfo);

        // Reference image views
        layoutRefImage   = findViewById(R.id.layoutRefImage);
        btnPickRefImage  = findViewById(R.id.btnPickRefImage);
        tvRefImageInfo   = findViewById(R.id.tvRefImageInfo);

        // Detection mode
        rbAnyFace        = findViewById(R.id.rbAnyFace);
        rbSpecificFace   = findViewById(R.id.rbSpecificFace);

        // Controls
        btnStartFilter   = findViewById(R.id.btnStartFilter);
        btnSaveMatched   = findViewById(R.id.btnSaveMatched);
        tvStatus         = findViewById(R.id.tvFilterStatus);
        tvResult         = findViewById(R.id.tvFilterResult);
        tvJobInfo        = findViewById(R.id.tvFilterJobInfo);
        progressBar      = findViewById(R.id.filterProgress);

        // Pre-select if a split video is available
        String lastJobId  = prefs.getString("last_job_id", "");
        String splitJobId = prefs.getString("split_job_id", "");
        String lastFile   = prefs.getString("last_filename", "");

        if (!splitJobId.isEmpty()) {
            currentJobId = splitJobId;
            tvVideoInfo.setText("✅ Using split clips from: " + lastFile
                    + "\n(Job: " + splitJobId + ")");
            tvVideoInfo.setTextColor(getColor(R.color.colorSuccess));
            btnStartFilter.setEnabled(true);
        } else {
            tvVideoInfo.setText("⚠️ No clips found. Download & split a video first, or pick from device.");
            tvVideoInfo.setTextColor(getColor(R.color.colorError));
            btnStartFilter.setEnabled(false);
        }
        btnUseDownloaded.setEnabled(!lastJobId.isEmpty());

        // Reference image panel — only visible for specific face mode
        layoutRefImage.setVisibility(View.GONE);

        rbSpecificFace.setOnCheckedChangeListener((btn, checked) -> {
            layoutRefImage.setVisibility(checked ? View.VISIBLE : View.GONE);
        });
        rbAnyFace.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) layoutRefImage.setVisibility(View.GONE);
        });

        btnSaveMatched.setVisibility(View.GONE);

        btnUseDownloaded.setOnClickListener(v -> useDownloadedClips());
        btnPickVideo.setOnClickListener(v -> pickVideo());
        btnPickRefImage.setOnClickListener(v -> pickRefImage());
        btnStartFilter.setOnClickListener(v -> startFilter());
        btnSaveMatched.setOnClickListener(v -> saveMatchedToPhone());
    }

    // ── Use already-split downloaded video ──────────────────────────────────
    void useDownloadedClips() {
        String jobId = prefs.getString("split_job_id",
                prefs.getString("last_job_id", ""));
        String fname = prefs.getString("last_filename", "");
        if (jobId.isEmpty()) {
            toast("No downloaded video found.");
            return;
        }
        currentJobId = jobId;
        prefs.edit().putString("face_filter_job_id", jobId).apply();
        tvVideoInfo.setText("✅ Using: " + fname + "\n(Job: " + jobId + ")");
        tvVideoInfo.setTextColor(getColor(R.color.colorSuccess));
        btnStartFilter.setEnabled(true);
        setStatus("Video selected. Choose mode and tap Start.", "#4CAF50");
    }

    // ── Pick video from device storage ───────────────────────────────────────
    void pickVideo() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        startActivityForResult(Intent.createChooser(i, "Select Video"), REQ_PICK_VIDEO);
    }

    // ── Pick reference image from gallery ────────────────────────────────────
    void pickRefImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(Intent.createChooser(i, "Select Reference Photo"), REQ_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != Activity.RESULT_OK || data == null) return;

        if (req == REQ_PICK_VIDEO) {
            uploadVideoToServer(data.getData());
        } else if (req == REQ_PICK_IMAGE) {
            uploadReferenceImage(data.getData());
        }
    }

    // ── Upload video from device → server → split ────────────────────────────
    void uploadVideoToServer(Uri uri) {
        setStatus("Preparing video upload...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        btnPickVideo.setEnabled(false);
        btnStartFilter.setEnabled(false);

        new Thread(() -> {
            try {
                String filename = getFileName(uri);
                File   temp     = new File(getCacheDir(), filename);
                InputStream  is  = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192]; int len;
                while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
                is.close(); fos.close();

                long sizeMb = temp.length() / 1048576;
                runOnUiThread(() -> setStatus(
                        "Uploading " + filename + " (" + sizeMb + " MB)...", "#F9A825"));

                ApiClient.uploadVideo(temp, new okhttp3.Callback() {
                    public void onFailure(Call c, IOException e) {
                        runOnUiThread(() -> {
                            setStatus("Upload failed: " + e.getMessage(), "#F44336");
                            progressBar.setIndeterminate(false);
                            progressBar.setVisibility(View.GONE);
                            btnPickVideo.setEnabled(true);
                        });
                    }
                    public void onResponse(Call c, Response r) throws IOException {
                        try {
                            JSONObject json = new JSONObject(r.body().string());
                            if (json.has("error")) {
                                runOnUiThread(() ->
                                        setStatus("Error: " + json.optString("error"), "#F44336"));
                                return;
                            }
                            String jobId = json.getString("job_id");
                            String fname = json.getString("filename");
                            double size  = json.optDouble("size_mb", 0);

                            // Now split the uploaded video (default 4s clips)
                            runOnUiThread(() -> setStatus("Upload done. Auto-splitting...", "#F9A825"));
                            autoSplitVideo(jobId, fname, size);
                        } catch (Exception e) {
                            runOnUiThread(() -> setStatus("Error: " + e.getMessage(), "#F44336"));
                        }
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("Error: " + e.getMessage(), "#F44336");
                    btnPickVideo.setEnabled(true);
                    progressBar.setVisibility(View.GONE);
                });
            }
        }).start();
    }

    void autoSplitVideo(String jobId, String fname, double sizeMb) {
        try {
            JSONObject body = new JSONObject();
            body.put("job_id", jobId);
            body.put("clip_seconds", 4);
            ApiClient.post("/split", body, new ApiClient.ApiCallback() {
                public void onSuccess(String resp) {
                    try {
                        String splitJobId = new JSONObject(resp).getString("split_job_id");
                        pollSplitJob(splitJobId, jobId, fname);
                    } catch (Exception e) {
                        runOnUiThread(() -> setStatus("Split error: " + e.getMessage(), "#F44336"));
                    }
                }
                public void onError(String err) {
                    runOnUiThread(() -> setStatus("Split error: " + err, "#F44336"));
                }
            });
        } catch (Exception e) {
            runOnUiThread(() -> setStatus("Error: " + e.getMessage(), "#F44336"));
        }
    }

    void pollSplitJob(String splitJobId, String originalJobId, String fname) {
        Runnable poll = new Runnable() {
            public void run() {
                ApiClient.get("/job/" + splitJobId, new ApiClient.ApiCallback() {
                    public void onSuccess(String resp) {
                        try {
                            JSONObject j  = new JSONObject(resp);
                            String status = j.optString("status", "");
                            int pct       = (int) j.optDouble("percent", 0);
                            runOnUiThread(() -> {
                                progressBar.setIndeterminate(false);
                                progressBar.setProgress(pct);
                                setStatus("Splitting... " + pct + "%", "#F9A825");
                            });
                            if (status.equals("done")) {
                                int count = j.optInt("count", 0);
                                currentJobId = originalJobId;
                                prefs.edit()
                                        .putString("split_job_id", originalJobId)
                                        .putString("face_filter_job_id", originalJobId)
                                        .apply();
                                runOnUiThread(() -> {
                                    progressBar.setProgress(100);
                                    tvVideoInfo.setText("✅ " + fname + " → " + count + " clips ready");
                                    tvVideoInfo.setTextColor(getColor(R.color.colorSuccess));
                                    setStatus("Split complete! Now tap Start Detection.", "#4CAF50");
                                    btnPickVideo.setEnabled(true);
                                    btnStartFilter.setEnabled(true);
                                });
                            } else if (status.equals("failed")) {
                                runOnUiThread(() -> {
                                    setStatus("Split failed: " + j.optString("error"), "#F44336");
                                    btnPickVideo.setEnabled(true);
                                    progressBar.setVisibility(View.GONE);
                                });
                            } else {
                                handler.postDelayed(this, 1500);
                            }
                        } catch (Exception e) {
                            runOnUiThread(() -> setStatus("Error: " + e.getMessage(), "#F44336"));
                        }
                    }
                    public void onError(String err) { handler.postDelayed(this, 3000); }
                });
            }
        };
        handler.post(poll);
    }

    // ── Upload reference face image ───────────────────────────────────────────
    void uploadReferenceImage(Uri uri) {
        if (currentJobId == null || currentJobId.isEmpty()) {
            toast("Select a video first, then pick reference image.");
            return;
        }
        setStatus("Uploading reference image...", "#F9A825");
        tvRefImageInfo.setText("Uploading...");
        btnPickRefImage.setEnabled(false);

        new Thread(() -> {
            try {
                // Copy URI to temp file
                String filename = getFileName(uri);
                File   temp     = new File(getCacheDir(), "ref_" + filename);
                InputStream      is  = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[4096]; int len;
                while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
                is.close(); fos.close();

                // Use ApiClient helper
                ApiClient.uploadRefFace(temp, currentJobId, new ApiClient.ApiCallback() {
                    public void onSuccess(String resp) {
                        try {
                            JSONObject json = new JSONObject(resp);
                            runOnUiThread(() -> {
                                btnPickRefImage.setEnabled(true);
                                if (json.optBoolean("success", false)) {
                                    tvRefImageInfo.setText("✅ Reference face uploaded!\n"
                                            + json.optString("message", ""));
                                    tvRefImageInfo.setTextColor(getColor(R.color.colorSuccess));
                                    setStatus("Reference image ready. Tap Start Detection.", "#4CAF50");
                                } else {
                                    String err = json.optString("error", "Upload failed");
                                    tvRefImageInfo.setText("❌ " + err);
                                    tvRefImageInfo.setTextColor(getColor(R.color.colorError));
                                    setStatus("Reference image error: " + err, "#F44336");
                                }
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> {
                                tvRefImageInfo.setText("❌ Parse error: " + e.getMessage());
                                btnPickRefImage.setEnabled(true);
                            });
                        }
                    }
                    public void onError(String err) {
                        runOnUiThread(() -> {
                            tvRefImageInfo.setText("❌ " + err);
                            tvRefImageInfo.setTextColor(getColor(R.color.colorError));
                            btnPickRefImage.setEnabled(true);
                            setStatus("Upload failed: " + err, "#F44336");
                        });
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvRefImageInfo.setText("❌ " + e.getMessage());
                    btnPickRefImage.setEnabled(true);
                    setStatus("Upload error: " + e.getMessage(), "#F44336");
                });
            }
        }).start();
    }

    // ── Start face detection ─────────────────────────────────────────────────
    void startFilter() {
        if (currentJobId == null || currentJobId.isEmpty()) {
            toast("Select a video first."); return;
        }
        boolean isSpecific = rbSpecificFace.isChecked();

        tvStatus.setText("Starting face detection...");
        tvStatus.setTextColor(0xFFF9A825);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        btnStartFilter.setEnabled(false);
        btnSaveMatched.setVisibility(View.GONE);
        tvResult.setText("");

        try {
            JSONObject body = new JSONObject();
            body.put("job_id", currentJobId);
            body.put("filter_type", isSpecific ? "specific" : "any");

            ApiClient.post("/face-filter", body, new ApiClient.ApiCallback() {
                public void onSuccess(String resp) {
                    try {
                        String filterId = new JSONObject(resp).getString("filter_job_id");
                        startPolling(filterId);
                    } catch (Exception e) { handleError(e.getMessage()); }
                }
                public void onError(String err) { handleError(err); }
            });
        } catch (Exception e) { handleError(e.getMessage()); }
    }

    // ── Poll filter job ──────────────────────────────────────────────────────
    void startPolling(String filterJobId) {
        isPollRunning = true;
        pollRunnable = new Runnable() {
            public void run() {
                if (!isPollRunning) return;
                ApiClient.get("/job/" + filterJobId, new ApiClient.ApiCallback() {
                    public void onSuccess(String resp) {
                        try {
                            JSONObject j  = new JSONObject(resp);
                            String status = j.optString("status", "");
                            int pct       = (int) j.optDouble("percent", 0);
                            int matched   = j.optInt("count", 0);
                            int total     = j.optInt("total", 0);

                            runOnUiThread(() -> {
                                progressBar.setProgress(pct);
                                tvStatus.setText("Scanning " + pct + "% — "
                                        + matched + "/" + total + " matched so far...");
                            });

                            if (status.equals("done")) {
                                stopPolling();
                                runOnUiThread(() -> {
                                    progressBar.setProgress(100);
                                    tvStatus.setText("✅ Detection complete!");
                                    tvStatus.setTextColor(0xFF4CAF50);

                                    if (matched > 0) {
                                        tvResult.setText("🎯 " + matched + " / " + total
                                                + " clips contain the face!\n\n"
                                                + "Tap below to save to phone.");
                                        tvResult.setTextColor(0xFF4CAF50);
                                        btnSaveMatched.setVisibility(View.VISIBLE);
                                        btnSaveMatched.setText("💾 Save " + matched + " Clips to Phone");
                                    } else {
                                        tvResult.setText("😔 No matching faces found in "
                                                + total + " clips.");
                                        tvResult.setTextColor(0xFFF44336);
                                    }
                                    btnStartFilter.setEnabled(true);
                                });
                            } else if (status.equals("failed")) {
                                stopPolling();
                                handleError(j.optString("error", "Filter failed"));
                            } else {
                                handler.postDelayed(pollRunnable, 1500);
                            }
                        } catch (Exception e) { handleError(e.getMessage()); }
                    }
                    public void onError(String err) { handler.postDelayed(pollRunnable, 3000); }
                });
            }
        };
        handler.post(pollRunnable);
    }

    // ── Save matched clips to phone ───────────────────────────────────────────
    void saveMatchedToPhone() {
        btnSaveMatched.setEnabled(false);
        btnSaveMatched.setText("Downloading...");
        setStatus("Saving matched clips to phone...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);

        String filename = "matched_" + currentJobId + ".zip";
        FileDownloader.downloadToPhone(this,
                "/get-matched/" + currentJobId, filename,
                new FileDownloader.DownloadCallback() {
                    public void onProgress(int pct) {
                        runOnUiThread(() -> progressBar.setProgress(pct));
                    }
                    public void onSuccess(String path) {
                        runOnUiThread(() -> {
                            progressBar.setProgress(100);
                            setStatus("✅ Clips saved!\nLocation: " + path
                                    + "\n\nExtract ZIP to get MP4 clips.", "#4CAF50");
                            btnSaveMatched.setText("✅ Saved to Phone!");
                            toast("Saved to: " + path);
                        });
                    }
                    public void onError(String err) {
                        runOnUiThread(() -> {
                            setStatus("Save failed: " + err, "#F44336");
                            btnSaveMatched.setEnabled(true);
                            btnSaveMatched.setText("💾 Save Matched Clips");
                        });
                    }
                });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    void stopPolling() {
        isPollRunning = false;
        if (pollRunnable != null) handler.removeCallbacks(pollRunnable);
    }

    void handleError(String err) {
        stopPolling();
        runOnUiThread(() -> {
            setStatus("❌ " + err, "#F44336");
            progressBar.setVisibility(View.GONE);
            btnStartFilter.setEnabled(true);
        });
    }

    void setStatus(String msg, String hex) {
        tvStatus.setText(msg);
        tvStatus.setTextColor(android.graphics.Color.parseColor(hex));
    }

    void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    String getFileName(Uri uri) {
        String result = "file";
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) result = c.getString(0);
        } catch (Exception ignored) {}
        return result;
    }

    @Override protected void onDestroy() { super.onDestroy(); stopPolling(); }
}
