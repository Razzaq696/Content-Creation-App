package com.abdultool.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import com.abdultool.R;
import okhttp3.*;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.*;

public class AdminActivity extends AppCompatActivity {

    // User list
    ListView lvUsers;
    ArrayAdapter<String> userAdapter;
    List<String> userDisplayList = new ArrayList<>();
    List<String[]> userDataList  = new ArrayList<>(); // [uid, email, role]

    // Create user
    EditText etNewEmail, etNewPass;
    Spinner spinnerRole;
    Button btnCreateUser, btnRefreshUsers;
    TextView tvAdminStatus;
    ProgressBar progressBar;

    // License section
    EditText etLicenseKey;
    Spinner spinnerPlan, spinnerDevices;
    EditText etExpiry;
    Button btnCreateLicense, btnRefreshLicenses;
    ListView lvLicenses;
    ArrayAdapter<String> licenseAdapter;
    List<String> licenseDisplayList = new ArrayList<>();

    SharedPreferences prefs;
    String idToken = "";

    private static final String DB_URL  = "https://abdul-tool-default-rtdb.firebaseio.com";
    private static final String FB_KEY  = "AIzaSyD3-ZBVajRdHmnWjjdsuJDZlNhFrKITB2E";

    OkHttpClient http = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS).build();
    MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        prefs   = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        idToken = prefs.getString("id_token", "");

        // User management views
        lvUsers        = findViewById(R.id.lvUsers);
        etNewEmail     = findViewById(R.id.etNewEmail);
        etNewPass      = findViewById(R.id.etNewPass);
        spinnerRole    = findViewById(R.id.spinnerRole);
        btnCreateUser  = findViewById(R.id.btnCreateUser);
        btnRefreshUsers= findViewById(R.id.btnRefreshUsers);
        tvAdminStatus  = findViewById(R.id.tvAdminStatus);
        progressBar    = findViewById(R.id.adminProgress);

        // License views
        etLicenseKey      = findViewById(R.id.etLicenseKey);
        spinnerPlan       = findViewById(R.id.spinnerPlan);
        spinnerDevices    = findViewById(R.id.spinnerDevices);
        etExpiry          = findViewById(R.id.etExpiry);
        btnCreateLicense  = findViewById(R.id.btnCreateLicense);
        btnRefreshLicenses= findViewById(R.id.btnRefreshLicenses);
        lvLicenses        = findViewById(R.id.lvLicenses);

        // Role spinner
        ArrayAdapter<String> roleAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"user", "admin"});
        roleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(roleAdapter);

        // Plan spinner
        ArrayAdapter<String> planAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"trial", "pro", "lifetime"});
        planAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPlan.setAdapter(planAdapter);
        spinnerPlan.setSelection(1); // default pro

        // Devices spinner
        ArrayAdapter<String> devAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, new String[]{"1","2","3","5","10"});
        devAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDevices.setAdapter(devAdapter);

        // User list adapter
        userAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userDisplayList);
        lvUsers.setAdapter(userAdapter);

        // License list adapter
        licenseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, licenseDisplayList);
        lvLicenses.setAdapter(licenseAdapter);

        // Long click on user → toggle role / delete
        lvUsers.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < userDataList.size()) {
                String[] user = userDataList.get(position);
                showUserOptions(user[0], user[1], user[2]);
            }
            return true;
        });

        // Long click on license → revoke
        lvLicenses.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < licenseDisplayList.size()) {
                String line = licenseDisplayList.get(position);
                String key = line.split("\\|")[0].trim();
                showRevokeDialog(key);
            }
            return true;
        });

        btnRefreshUsers.setOnClickListener(v -> loadUsers());
        btnCreateUser.setOnClickListener(v -> createUser());
        btnCreateLicense.setOnClickListener(v -> createLicense());
        btnRefreshLicenses.setOnClickListener(v -> loadLicenses());

        loadUsers();
        loadLicenses();
    }

    // ── Load Users ────────────────────────────────────────────────────────────
    void loadUsers() {
        setLoading(true);
        tvAdminStatus.setText("Loading users...");
        new Thread(() -> {
            try {
                // Get all roles from DB
                String rolesUrl = DB_URL + "/user_roles.json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder().url(rolesUrl).build();
                Response resp = http.newCall(req).execute();
                String body = resp.body().string();

                List<String> display = new ArrayList<>();
                List<String[]> data  = new ArrayList<>();

                if (!body.equals("null") && !body.isEmpty()) {
                    JSONObject roles = new JSONObject(body);
                    Iterator<String> keys = roles.keys();
                    int i = 1;
                    while (keys.hasNext()) {
                        String uid  = keys.next();
                        String role = roles.getString(uid);
                        String short_uid = uid.length() > 14 ? uid.substring(0, 14) + "..." : uid;
                        display.add(i++ + ".  Role: " + role.toUpperCase() + "\n    UID: " + short_uid);
                        data.add(new String[]{uid, uid, role});
                    }
                }

                runOnUiThread(() -> {
                    userDisplayList.clear();
                    userDataList.clear();
                    if (display.isEmpty()) {
                        userDisplayList.add("No users found in database.");
                    } else {
                        userDisplayList.addAll(display);
                        userDataList.addAll(data);
                    }
                    userAdapter.notifyDataSetChanged();
                    setLoading(false);
                    tvAdminStatus.setText("Users loaded: " + userDataList.size());
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvAdminStatus.setText("Error: " + e.getMessage());
                    setLoading(false);
                });
            }
        }).start();
    }

    // ── Create User ───────────────────────────────────────────────────────────
    void createUser() {
        String email = etNewEmail.getText().toString().trim();
        String pass  = etNewPass.getText().toString().trim();
        String role  = spinnerRole.getSelectedItem().toString();

        if (email.isEmpty() || pass.length() < 6) {
            tvAdminStatus.setText("Enter valid email and password (min 6 chars)");
            tvAdminStatus.setTextColor(getColor(R.color.colorError));
            return;
        }
        setLoading(true);
        tvAdminStatus.setText("Creating user...");

        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", pass);
                body.put("returnSecureToken", false);

                Request req = new Request.Builder()
                    .url("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + FB_KEY)
                    .post(RequestBody.create(body.toString(), JSON_TYPE))
                    .build();
                Response resp = http.newCall(req).execute();
                JSONObject json = new JSONObject(resp.body().string());

                if (json.has("error")) {
                    String err = json.getJSONObject("error").getString("message");
                    runOnUiThread(() -> {
                        tvAdminStatus.setText("Error: " + err);
                        tvAdminStatus.setTextColor(getColor(R.color.colorError));
                        setLoading(false);
                    });
                } else {
                    String uid = json.getString("localId");
                    // Set role in DB
                    String dbUrl = DB_URL + "/user_roles/" + uid + ".json"
                        + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                    Request dbReq = new Request.Builder()
                        .url(dbUrl)
                        .put(RequestBody.create("\"" + role + "\"", JSON_TYPE))
                        .build();
                    http.newCall(dbReq).execute();

                    runOnUiThread(() -> {
                        tvAdminStatus.setText("✅ User created: " + email + " (" + role + ")");
                        tvAdminStatus.setTextColor(getColor(R.color.colorSuccess));
                        etNewEmail.setText("");
                        etNewPass.setText("");
                        setLoading(false);
                        loadUsers();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvAdminStatus.setText("Error: " + e.getMessage());
                    setLoading(false);
                });
            }
        }).start();
    }

    // ── User Options Dialog ───────────────────────────────────────────────────
    void showUserOptions(String uid, String email, String currentRole) {
        String newRole = currentRole.equals("admin") ? "user" : "admin";
        new AlertDialog.Builder(this)
            .setTitle("User: " + uid.substring(0, Math.min(16, uid.length())))
            .setMessage("Current Role: " + currentRole.toUpperCase())
            .setPositiveButton("Toggle → " + newRole.toUpperCase(), (d, w) -> toggleRole(uid, newRole))
            .setNegativeButton("Delete User", (d, w) -> deleteUser(uid))
            .setNeutralButton("Cancel", null)
            .show();
    }

    void toggleRole(String uid, String newRole) {
        new Thread(() -> {
            try {
                String dbUrl = DB_URL + "/user_roles/" + uid + ".json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder()
                    .url(dbUrl)
                    .put(RequestBody.create("\"" + newRole + "\"", JSON_TYPE))
                    .build();
                http.newCall(req).execute();
                runOnUiThread(() -> {
                    tvAdminStatus.setText("✅ Role updated to " + newRole.toUpperCase());
                    loadUsers();
                });
            } catch (Exception e) {
                runOnUiThread(() -> tvAdminStatus.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    void deleteUser(String uid) {
        new Thread(() -> {
            try {
                // Remove from user_roles
                String dbUrl = DB_URL + "/user_roles/" + uid + ".json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder().url(dbUrl).delete().build();
                http.newCall(req).execute();
                // Remove session
                String sessUrl = DB_URL + "/active_sessions/" + uid + ".json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request sessReq = new Request.Builder().url(sessUrl).delete().build();
                http.newCall(sessReq).execute();

                runOnUiThread(() -> {
                    tvAdminStatus.setText("✅ User deleted");
                    loadUsers();
                });
            } catch (Exception e) {
                runOnUiThread(() -> tvAdminStatus.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    // ── License Manager ───────────────────────────────────────────────────────
    void loadLicenses() {
        new Thread(() -> {
            try {
                String url = DB_URL + "/licenses.json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder().url(url).build();
                Response resp = http.newCall(req).execute();
                String body = resp.body().string();

                List<String> display = new ArrayList<>();
                if (!body.equals("null") && !body.isEmpty()) {
                    JSONObject licenses = new JSONObject(body);
                    Iterator<String> keys = licenses.keys();
                    while (keys.hasNext()) {
                        String dbKey = keys.next();
                        JSONObject lic = licenses.getJSONObject(dbKey);
                        String displayKey = dbKey.replace("_", "-");
                        String plan    = lic.optString("plan", "?");
                        String expiry  = lic.optString("expiry", "Lifetime");
                        boolean active = lic.optBoolean("active", false);
                        int maxDev     = lic.optInt("max_devices", 1);
                        int used       = lic.optJSONObject("used_by") != null
                                        ? lic.getJSONObject("used_by").length() : 0;
                        display.add(displayKey + " | " + plan.toUpperCase()
                            + " | " + (active ? "✅" : "❌")
                            + " | " + used + "/" + maxDev + " devices"
                            + " | Exp: " + expiry);
                    }
                }

                runOnUiThread(() -> {
                    licenseDisplayList.clear();
                    if (display.isEmpty()) licenseDisplayList.add("No licenses found.");
                    else licenseDisplayList.addAll(display);
                    licenseAdapter.notifyDataSetChanged();
                });
            } catch (Exception e) {
                runOnUiThread(() -> licenseDisplayList.add("Error: " + e.getMessage()));
            }
        }).start();
    }

    void createLicense() {
        String key    = etLicenseKey.getText().toString().trim().toUpperCase();
        String plan   = spinnerPlan.getSelectedItem().toString();
        String devStr = spinnerDevices.getSelectedItem().toString();
        String expiry = etExpiry.getText().toString().trim();

        if (key.length() < 20) {
            tvAdminStatus.setText("Generate a key first (min 20 chars)");
            return;
        }
        // Auto-format key
        String raw = key.replace("-", "").replace("_", "");
        if (raw.length() < 20) {
            tvAdminStatus.setText("Key too short. Format: XXXXX-XXXXX-XXXXX-XXXXX");
            return;
        }
        String dbKey = raw.substring(0,5) + "_" + raw.substring(5,10) + "_"
                     + raw.substring(10,15) + "_" + raw.substring(15,20);

        setLoading(true);
        new Thread(() -> {
            try {
                JSONObject licData = new JSONObject();
                licData.put("plan", plan);
                licData.put("active", true);
                licData.put("max_devices", Integer.parseInt(devStr));
                licData.put("expiry", expiry.isEmpty() ? JSONObject.NULL : expiry);
                licData.put("created_at", new java.text.SimpleDateFormat("yyyy-MM-dd",
                    java.util.Locale.getDefault()).format(new java.util.Date()));
                licData.put("used_by", new JSONObject());

                String url = DB_URL + "/licenses/" + dbKey + ".json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder()
                    .url(url)
                    .put(RequestBody.create(licData.toString(), JSON_TYPE))
                    .build();
                http.newCall(req).execute();

                runOnUiThread(() -> {
                    tvAdminStatus.setText("✅ License created: " + key.substring(0,5) + "-...");
                    tvAdminStatus.setTextColor(getColor(R.color.colorSuccess));
                    etLicenseKey.setText("");
                    setLoading(false);
                    loadLicenses();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    tvAdminStatus.setText("Error: " + e.getMessage());
                    setLoading(false);
                });
            }
        }).start();
    }

    void showRevokeDialog(String key) {
        new AlertDialog.Builder(this)
            .setTitle("Revoke License")
            .setMessage("Revoke: " + key + "?")
            .setPositiveButton("Revoke", (d, w) -> revokeLicense(key))
            .setNegativeButton("Cancel", null)
            .show();
    }

    void revokeLicense(String displayKey) {
        String dbKey = displayKey.replace("-", "_");
        new Thread(() -> {
            try {
                String url = DB_URL + "/licenses/" + dbKey + "/active.json"
                    + (idToken.isEmpty() ? "" : "?auth=" + idToken);
                Request req = new Request.Builder()
                    .url(url)
                    .put(RequestBody.create("false", JSON_TYPE))
                    .build();
                http.newCall(req).execute();
                runOnUiThread(() -> {
                    tvAdminStatus.setText("✅ License revoked");
                    loadLicenses();
                });
            } catch (Exception e) {
                runOnUiThread(() -> tvAdminStatus.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    // ── Key Generator ─────────────────────────────────────────────────────────
    String generateKey() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        java.util.Random rand = new java.util.Random();
        StringBuilder sb = new StringBuilder();
        for (int g = 0; g < 4; g++) {
            for (int c = 0; c < 5; c++) sb.append(chars.charAt(rand.nextInt(chars.length())));
            if (g < 3) sb.append("-");
        }
        return sb.toString();
    }

    // Called from XML onClick
    public void onGenerateKey(android.view.View v) {
        etLicenseKey.setText(generateKey());
    }

    void setLoading(boolean loading) {
        runOnUiThread(() -> {
            progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
            btnCreateUser.setEnabled(!loading);
            btnCreateLicense.setEnabled(!loading);
        });
    }
}
