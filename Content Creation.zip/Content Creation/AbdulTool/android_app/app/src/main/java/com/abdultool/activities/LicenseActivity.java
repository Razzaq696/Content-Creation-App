package com.abdultool.activities;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.utils.FirebaseHelper;

public class LicenseActivity extends AppCompatActivity {
    EditText etKey;
    Button btnActivate, btnTrial;
    TextView tvStatus;
    ProgressBar progressBar;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_license);

        prefs       = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        etKey       = findViewById(R.id.etLicenseKey);
        btnActivate = findViewById(R.id.btnActivate);
        btnTrial    = findViewById(R.id.btnTrial);
        tvStatus    = findViewById(R.id.tvLicenseStatus);
        progressBar = findViewById(R.id.licenseProgress);

        // Check if already licensed
        String saved = prefs.getString("license_plan", "");
        if (!saved.isEmpty()) {
            goToLogin();
            return;
        }

        String savedKey = prefs.getString("license_key", "");
        if (!savedKey.isEmpty()) etKey.setText(savedKey);

        btnActivate.setOnClickListener(v -> activateLicense());
        btnTrial.setOnClickListener(v -> useTrial());
    }

    void activateLicense() {
        String key = etKey.getText().toString().trim().toUpperCase();
        if (key.length() < 20) {
            tvStatus.setText("Invalid key format. Example: ABCDE-FGHIJ-KLMNO-PQRST");
            tvStatus.setTextColor(getColor(R.color.colorError));
            return;
        }
        setLoading(true);
        tvStatus.setText("Validating key...");
        tvStatus.setTextColor(getColor(R.color.colorWarning));

        FirebaseHelper.validateLicense(key, (success, plan, message) -> runOnUiThread(() -> {
            setLoading(false);
            if (success) {
                prefs.edit().putString("license_key", key)
                            .putString("license_plan", plan).apply();
                tvStatus.setText(message);
                tvStatus.setTextColor(getColor(R.color.colorSuccess));
                new android.os.Handler().postDelayed(this::goToLogin, 800);
            } else {
                tvStatus.setText(message);
                tvStatus.setTextColor(getColor(R.color.colorError));
            }
        }));
    }

    void useTrial() {
        prefs.edit().putString("license_plan", "trial").apply();
        goToLogin();
    }

    void goToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnActivate.setEnabled(!loading);
        btnTrial.setEnabled(!loading);
    }
}
