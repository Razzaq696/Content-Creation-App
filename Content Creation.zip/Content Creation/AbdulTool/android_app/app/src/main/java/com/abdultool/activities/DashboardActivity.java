package com.abdultool.activities;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.utils.FirebaseHelper;

public class DashboardActivity extends AppCompatActivity {
    TextView tvEmail, tvRole, tvPlan;
    Button btnVideoTool, btnAdmin, btnLogout;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        prefs       = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        tvEmail     = findViewById(R.id.tvUserEmail);
        tvRole      = findViewById(R.id.tvUserRole);
        tvPlan      = findViewById(R.id.tvUserPlan);
        btnVideoTool = findViewById(R.id.btnVideoTool);
        btnAdmin    = findViewById(R.id.btnAdmin);
        btnLogout   = findViewById(R.id.btnLogout);

        String email = prefs.getString("user_email", "");
        String role  = prefs.getString("user_role", "user");
        String plan  = prefs.getString("license_plan", "trial").toUpperCase();
        String uid   = prefs.getString("user_uid", "");

        tvEmail.setText(email);
        tvRole.setText(role.toUpperCase());
        tvPlan.setText(plan);

        // Admin gets all features regardless of plan
        boolean isAdmin = role.equals("admin");

        // Admin panel visibility
        btnAdmin.setVisibility(isAdmin ? View.VISIBLE : View.GONE);

        btnVideoTool.setOnClickListener(v ->
            startActivity(new Intent(this, VideoToolActivity.class)));

        btnAdmin.setOnClickListener(v ->
            startActivity(new Intent(this, AdminActivity.class)));

        btnLogout.setOnClickListener(v -> doLogout(uid));
    }

    void doLogout(String uid) {
        String idToken = prefs.getString("id_token", "");
        FirebaseHelper.logout(uid, idToken, () -> runOnUiThread(() -> {
            prefs.edit().remove("user_uid").remove("user_email")
                        .remove("user_role").apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }));
    }
}
