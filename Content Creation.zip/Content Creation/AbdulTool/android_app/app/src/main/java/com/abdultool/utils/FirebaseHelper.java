package com.abdultool.utils;
import okhttp3.*;
import org.json.JSONObject;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class FirebaseHelper {
    private static final String API_KEY = "AIzaSyD3-ZBVajRdHmnWjjdsuJDZlNhFrKITB2E";
    private static final String DB_URL  = "https://abdul-tool-default-rtdb.firebaseio.com";

    private static final OkHttpClient http = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS).build();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public interface LoginCallback {
        void onResult(boolean success, String uid, String message, String idToken);
    }

    public static void login(String email, String pass, LoginCallback cb) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", pass);
                body.put("returnSecureToken", true);
                Request req = new Request.Builder()
                    .url("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + API_KEY)
                    .post(RequestBody.create(body.toString(), JSON)).build();
                Response resp = http.newCall(req).execute();
                JSONObject json = new JSONObject(resp.body().string());
                if (json.has("error")) {
                    cb.onResult(false, null, json.getJSONObject("error").getString("message"), null);
                } else {
                    String uid   = json.getString("localId");
                    String token = json.getString("idToken");
                    dbSet("active_sessions/" + uid, "\"android_device\"", token);
                    cb.onResult(true, uid, "Login successful.", token);
                }
            } catch (Exception e) { cb.onResult(false, null, e.getMessage(), null); }
        }).start();
    }

    public interface RoleCallback { void onResult(String role); }

    public static void getRole(String uid, String idToken, RoleCallback cb) {
        new Thread(() -> {
            try {
                String url = DB_URL + "/user_roles/" + uid + ".json?auth=" + idToken;
                Request req = new Request.Builder().url(url).build();
                Response resp = http.newCall(req).execute();
                String body = resp.body().string().replace("\"", "").trim();
                cb.onResult(body.equals("admin") ? "admin" : "user");
            } catch (Exception e) { cb.onResult("user"); }
        }).start();
    }

    public interface LicenseCallback {
        void onResult(boolean success, String plan, String message);
    }

    public static void validateLicense(String key, LicenseCallback cb) {
        new Thread(() -> {
            try {
                String dbKey = key.replace("-", "_");
                String url   = DB_URL + "/licenses/" + dbKey + ".json";
                Request req  = new Request.Builder().url(url).build();
                Response resp = http.newCall(req).execute();
                String body  = resp.body().string();
                if (body.equals("null") || body.isEmpty()) {
                    cb.onResult(false, null, "License key not found."); return;
                }
                JSONObject json = new JSONObject(body);
                if (!json.optBoolean("active", false)) {
                    cb.onResult(false, null, "This license key has been deactivated."); return;
                }
                String plan = json.optString("plan", "trial");
                cb.onResult(true, plan, plan.toUpperCase() + " plan activated!");
            } catch (Exception e) { cb.onResult(false, null, "Error: " + e.getMessage()); }
        }).start();
    }

    public interface SimpleCallback { void onDone(); }

    public static void logout(String uid, String idToken, SimpleCallback cb) {
        new Thread(() -> {
            try { dbSet("active_sessions/" + uid, "null", idToken); }
            catch (Exception ignored) {}
            cb.onDone();
        }).start();
    }

    private static void dbSet(String path, String value, String token) throws IOException {
        String url = DB_URL + "/" + path + ".json"
                   + (token != null && !token.isEmpty() ? "?auth=" + token : "");
        Request req = new Request.Builder()
            .url(url).put(RequestBody.create(value, JSON)).build();
        http.newCall(req).execute();
    }
}
