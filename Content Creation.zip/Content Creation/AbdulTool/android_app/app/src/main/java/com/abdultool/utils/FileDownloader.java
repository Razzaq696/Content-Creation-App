package com.abdultool.utils;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.abdultool.api.ApiClient;
import okhttp3.*;
import java.io.*;

public class FileDownloader {

    public interface DownloadCallback {
        void onProgress(int percent);
        void onSuccess(String savedPath);
        void onError(String error);
    }

    /**
     * Download a file from server and save to phone Downloads folder
     * endpoint: /get-video/{job_id}  or  /get-clips/{job_id}
     */
    public static void downloadToPhone(Context ctx, String endpoint,
                                       String filename, DownloadCallback cb) {
        new Thread(() -> {
            try {
                // Build request
                Request req = new Request.Builder()
                        .url(ApiClient.BASE_URL + endpoint)
                        .addHeader("X-API-Key", ApiClient.API_KEY)
                        .build();

                OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                        .readTimeout(300, java.util.concurrent.TimeUnit.SECONDS)
                        .build();

                Response resp = client.newCall(req).execute();
                if (!resp.isSuccessful()) {
                    cb.onError("Server error: " + resp.code());
                    return;
                }

                ResponseBody body = resp.body();
                if (body == null) { cb.onError("Empty response"); return; }

                long total   = body.contentLength();
                InputStream  is = body.byteStream();

                // Save to Downloads folder
                OutputStream os;
                String savedPath;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Android 10+ — MediaStore
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(MediaStore.Downloads.MIME_TYPE,
                            filename.endsWith(".zip") ? "application/zip" : "video/mp4");
                    values.put(MediaStore.Downloads.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/AbdulTool/");

                    Uri uri = ctx.getContentResolver()
                            .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) { cb.onError("Could not create file"); return; }
                    os = ctx.getContentResolver().openOutputStream(uri);
                    savedPath = "Downloads/AbdulTool/" + filename;
                } else {
                    // Android 9 and below
                    File dir = new File(
                            Environment.getExternalStoragePublicDirectory(
                                    Environment.DIRECTORY_DOWNLOADS), "AbdulTool");
                    dir.mkdirs();
                    File outFile = new File(dir, filename);
                    os = new FileOutputStream(outFile);
                    savedPath = outFile.getAbsolutePath();
                }

                // Write with progress
                byte[] buf    = new byte[8192];
                long   written = 0;
                int    len;
                int    lastPct = 0;

                while ((len = is.read(buf)) != -1) {
                    os.write(buf, 0, len);
                    written += len;
                    if (total > 0) {
                        int pct = (int)(written * 100 / total);
                        if (pct != lastPct) {
                            lastPct = pct;
                            cb.onProgress(pct);
                        }
                    }
                }
                os.flush();
                os.close();
                is.close();

                cb.onSuccess(savedPath);

            } catch (Exception e) {
                cb.onError(e.getMessage());
            }
        }).start();
    }
}